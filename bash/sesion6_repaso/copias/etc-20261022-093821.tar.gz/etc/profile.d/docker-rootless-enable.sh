#!/bin/bash
[ -z "$USER" ] || [ "$USER" = "root" ] && return

#Habilitar y arrancar docker si no está activo

if systemctl --user is-enabled docker 2>/dev/null | grep -q "disabled"; then
    systemctl --user enable docker 2>/dev/null
fi

if systemctl --user is-active docker 2>/dev/null | grep -qE "(inactive|failed)"; then
    systemctl --user start docker 2>/dev/null &
fi

ID_USER=$(id -u)
sudo /usr/sbin/docker-gns3.sh $ID_USER

