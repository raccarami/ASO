#!/bin/bash
# Instalar CA en el perfil NSS del usuario (Chrome y Firefox)
CERT="/etc/ssl/certs/caminas-ca.pem"
CERT_NAME="IES El Caminas CA"

# Crear NSS database de Chrome si no existe
if [ ! -f "$HOME/.pki/nssdb/cert9.db" ]; then
    mkdir -p "$HOME/.pki/nssdb"
    certutil -d sql:"$HOME/.pki/nssdb" -N --empty-password 2>/dev/null
fi


for certdb in $(find "$HOME" -name "cert9.db" 2>/dev/null); do
    certdir=$(dirname $certdb)
    if ! certutil -L -d sql:$certdir 2>/dev/null | grep -q "$CERT_NAME"; then
        certutil -A -n "$CERT_NAME" -t "CT,," -i "$CERT" -d sql:$certdir 2>/dev/null
    fi
done
