usuario=$USER
sudo /usr/sbin/update-groups.sh $usuario
