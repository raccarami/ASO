#!/bin/bash
[ -z "$USER" ] || [ "$USER" = "root" ] && return

UID_CURRENT=$(id -u)
export DOCKER_HOST="unix:///run/user/${UID_CURRENT}/docker.sock"
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1

alias dc="docker compose"
alias dps="docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'"
alias dvls="docker volume ls"
alias dnls="docker network ls"
